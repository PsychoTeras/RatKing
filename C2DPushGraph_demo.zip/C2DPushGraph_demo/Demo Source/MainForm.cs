using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using CustomUIControls.Graphing; // Our control's namespace

namespace C2DPushGraphDemo
{
    public partial class MainForm : Form
    {
        const int SYSTEM_CPU_LINE = 1; // Our example line identification

        private C2DPushGraph.LineHandle          m_Line1Handle;
        private C2DPushGraph.LineHandle          m_Line2Handle;
        private System.Threading.Timer           m_Timer;
        private System.Threading.TimerCallback   m_TimerCallback;
        private System.Threading.Mutex           m_CtrlMutex;
        private PerformanceCounter               m_CPUPerfCounter;
        private PerformanceCounter               m_CPUPerfCounter_Process;

        public MainForm()
        {
            InitializeComponent();
            m_CtrlMutex = new System.Threading.Mutex();

            m_CPUPerfCounter = new PerformanceCounter();

            m_CPUPerfCounter.CategoryName = "Processor";
            m_CPUPerfCounter.CounterName  = "% Processor Time";
            m_CPUPerfCounter.InstanceName = "_Total";
                        
            m_CPUPerfCounter_Process = new PerformanceCounter();
                        
            m_CPUPerfCounter_Process.CategoryName = "Process";
            m_CPUPerfCounter_Process.CounterName = "% Processor Time";

            m_CPUPerfCounter_Process.InstanceName = GetCurrentProcessInstanceName();
        }

        // ===================================================================       

        private static string GetCurrentProcessInstanceName()
        {
            Process proc = Process.GetCurrentProcess();
            int pid = proc.Id;
            return GetProcessInstanceName(pid);
        }

        // ===================================================================       

        private static string GetProcessInstanceName(int pid)
        {
            PerformanceCounterCategory cat = new PerformanceCounterCategory("Process");

            string[] instances = cat.GetInstanceNames();
            foreach (string instance in instances)
            {

                using (PerformanceCounter cnt = new PerformanceCounter("Process",
                     "ID Process", instance, true))
                {
                    int val = (int)cnt.RawValue;
                    if (val == pid)
                    {
                        return instance;
                    }
                }
            }
            throw new Exception("Could not find performance counter " +
                "instance name for current process. This is truly strange ...");
        }

        // ===================================================================       

        private void Form1_Load(object sender, EventArgs e)
        {

            /* Show our splash screen */

            Splash splash = new Splash();            
            splash.ShowDialog();
            splash.Dispose();


            /* Make sure our drop down lists are non-editable */

            m_cmbLine1Thickness.DropDownStyle = ComboBoxStyle.DropDownList;
            m_cmbLine2Thickness.DropDownStyle = ComboBoxStyle.DropDownList;
            m_cmbLineInterval.DropDownStyle   = ComboBoxStyle.DropDownList;

                      
            /* Even though this isn't required since everything is setup in
             * the form designer, I'll do it to demonstrate setting some
             * properties */

            m_PushGraphCtrl.BackColor        = Color.Black;            
            m_PushGraphCtrl.MaxLabel         = "100%";
            m_PushGraphCtrl.MaxPeekMagnitude = 100;
            m_PushGraphCtrl.MinLabel         = "0%";
            m_PushGraphCtrl.MinPeekMagnitude = 0;
            m_PushGraphCtrl.LineInterval     = 8;     


            /* We don't need to worry about built in race condition 
             * protection in this demo */

            Control.CheckForIllegalCrossThreadCalls = false;


            /* Add our two example lines, we'll use one that has a numerical
             * identification (better performance) and one that has a string
             * based identification (more convenient). 
             
             * For the second line we'll get our handle after adding the line
             * for demonstration purposes. Note you can use GetLineHandle at any
             * time.*/

            m_Line1Handle = m_PushGraphCtrl.AddLine(SYSTEM_CPU_LINE, Color.White);

            m_PushGraphCtrl.AddLine("Process CPU Line", Color.Red);
            m_Line2Handle = m_PushGraphCtrl.GetLineHandle("Process CPU Line");


            /* Ensure our graph isn't covered up by any other controls */
            Controls.SetChildIndex(m_PushGraphCtrl, 0);                   

            /* Create and start our timer */
            m_TimerCallback = new System.Threading.TimerCallback(onTimerTick);
            m_Timer = new System.Threading.Timer(m_TimerCallback, null, 0, 500);
            
        }

        // ===================================================================       
        
        private void onTimerTick( object obj)
        {
            Random rand = new Random();

            int systemCPUUsage  = (int)Math.Ceiling(m_CPUPerfCounter.NextValue());
            int processCPUUsage = (int)Math.Floor(m_CPUPerfCounter_Process.NextValue());

            if (processCPUUsage > systemCPUUsage)
            {
                processCPUUsage = systemCPUUsage;
            }
            
            m_CtrlMutex.WaitOne();

            m_PushGraphCtrl.Push(systemCPUUsage, SYSTEM_CPU_LINE);
            m_PushGraphCtrl.Push(processCPUUsage, "Process CPU Line");
            m_PushGraphCtrl.UpdateGraph();

            m_CtrlMutex.ReleaseMutex();
        }

        // ===================================================================       
   
        private void m_chckHighQuality_CheckedChanged(object sender, EventArgs e)
        {
            m_CtrlMutex.WaitOne();
            m_PushGraphCtrl.HighQuality = m_chckHighQuality.Checked;
            m_CtrlMutex.ReleaseMutex();
        }

        // ===================================================================       

        private void m_chckLine1Visible_CheckedChanged(object sender, EventArgs e)
        {
            m_CtrlMutex.WaitOne();
            m_Line1Handle.Visible = m_chckLine1Visible.Checked;
            m_CtrlMutex.ReleaseMutex();
        }

        // ===================================================================       

        private void m_btnLine1Color_Click(object sender, EventArgs e)
        {
            ColorDialog clrDlg = new ColorDialog();
            clrDlg.Color = m_Line1Handle.Color;

            if (clrDlg.ShowDialog() == DialogResult.OK)
            {
                m_btnLine1Color.BackColor = clrDlg.Color;
                m_CtrlMutex.WaitOne();
                m_Line1Handle.Color = clrDlg.Color;
                m_CtrlMutex.ReleaseMutex();
            }

            clrDlg.Dispose();
        }

        // ===================================================================       

        private void m_btnLine2Color_Click(object sender, EventArgs e)
        {
            ColorDialog clrDlg = new ColorDialog();
            clrDlg.Color = m_Line2Handle.Color;

            if (clrDlg.ShowDialog() == DialogResult.OK)
            {
                m_btnLine2Color.BackColor = clrDlg.Color;
                m_CtrlMutex.WaitOne();
                m_Line2Handle.Color = clrDlg.Color;
                m_CtrlMutex.ReleaseMutex();
            }

            clrDlg.Dispose();
        }

        // ===================================================================       

        private void m_chckLine2Visible_CheckedChanged(object sender, EventArgs e)
        {
            m_CtrlMutex.WaitOne();
            m_Line2Handle.Visible = m_chckLine2Visible.Checked;
            m_CtrlMutex.ReleaseMutex();
        }

        // ===================================================================       

        private void m_btnBackColor_Click(object sender, EventArgs e)
        {
            ColorDialog clrDlg = new ColorDialog();
            clrDlg.Color = m_PushGraphCtrl.BackColor;

            if (clrDlg.ShowDialog() == DialogResult.OK)
            {
                if (m_PushGraphCtrl.BackgroundImage != null)
                {
                    m_PushGraphCtrl.BackgroundImage.Dispose();
                    m_PushGraphCtrl.BackgroundImage = null;
                }

                m_btnBackColor.BackColor = clrDlg.Color;
                m_CtrlMutex.WaitOne();
                m_PushGraphCtrl.BackColor = clrDlg.Color;
                m_CtrlMutex.ReleaseMutex();
            }

            clrDlg.Dispose();
        }

        // ===================================================================       

        private void m_btnGridColor_Click(object sender, EventArgs e)
        {
            ColorDialog clrDlg = new ColorDialog();
            clrDlg.Color = m_PushGraphCtrl.GridColor;

            if (clrDlg.ShowDialog() == DialogResult.OK)
            {
                m_btnGridColor.BackColor = clrDlg.Color;
                m_CtrlMutex.WaitOne();
                m_PushGraphCtrl.GridColor = clrDlg.Color;
                m_CtrlMutex.ReleaseMutex();
            }

            clrDlg.Dispose();
        }

        // ===================================================================       

        private void m_btnTextColor_Click(object sender, EventArgs e)
        {
            ColorDialog clrDlg = new ColorDialog();
            clrDlg.Color = m_PushGraphCtrl.TextColor;

            if (clrDlg.ShowDialog() == DialogResult.OK)
            {
                m_btnTextColor.BackColor = clrDlg.Color;
                m_CtrlMutex.WaitOne();
                m_PushGraphCtrl.TextColor = clrDlg.Color;
                m_CtrlMutex.ReleaseMutex();
            }

            clrDlg.Dispose();
        }

        // ===================================================================       

        private void m_chckShowLabels_CheckedChanged(object sender, EventArgs e)
        {
            m_CtrlMutex.WaitOne();
            m_PushGraphCtrl.ShowLabels = m_chckShowLabels.Checked;
            m_CtrlMutex.ReleaseMutex();
        }

        // ===================================================================       

        private void m_chckShowGrid_CheckedChanged(object sender, EventArgs e)
        {
            m_CtrlMutex.WaitOne();
            m_PushGraphCtrl.ShowGrid = m_chckShowGrid.Checked;
            m_CtrlMutex.ReleaseMutex();
        }

        // ===================================================================       

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            m_Timer.Change(-1, -1);
            System.Threading.Thread.Sleep(1000);
            m_Timer.Dispose();
        }

        // ===================================================================       

        private void m_btnApply_Click(object sender, EventArgs e)
        {
            int updateTime = 0;
            try
            {
                updateTime = System.Convert.ToInt32(m_txtUpdateTime.Text);
            }
            catch (System.FormatException)
            {
                updateTime = 100;
            }

            if (updateTime < 100)
            {
                updateTime = 100;
            }

            m_Timer.Change(0, updateTime);
            m_txtUpdateTime.Text = updateTime.ToString();
        }

        // ===================================================================       
        
        private void m_chkLine1BarStyle_CheckedChanged(object sender, EventArgs e)
        {
            m_CtrlMutex.WaitOne();
            m_Line1Handle.ShowAsBar = m_chkLine1BarStyle.Checked;
            m_CtrlMutex.ReleaseMutex();
        }

        // ===================================================================       

        private void m_chkLine2BarStyle_CheckedChanged(object sender, EventArgs e)
        {
            m_CtrlMutex.WaitOne();
            m_Line2Handle.ShowAsBar = m_chkLine2BarStyle.Checked;
            m_CtrlMutex.ReleaseMutex();
        }

        // ===================================================================       

        private void m_cmbLine1Thickness_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_CtrlMutex.WaitOne();
            m_Line1Handle.Thickness = 
                System.Convert.ToUInt32(m_cmbLine1Thickness.Text);
            m_CtrlMutex.ReleaseMutex();
        }

        // ===================================================================       

        private void m_cmbLine2Thickness_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_CtrlMutex.WaitOne();
            m_Line2Handle.Thickness =
                System.Convert.ToUInt32(m_cmbLine2Thickness.Text);
            m_CtrlMutex.ReleaseMutex();
        }

        // ===================================================================       

        private void m_cmbLineInterval_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_CtrlMutex.WaitOne();
            m_PushGraphCtrl.LineInterval =
                (ushort)System.Convert.ToUInt32(m_cmbLineInterval.Text);
            m_CtrlMutex.ReleaseMutex();
        }

        // ===================================================================       

        private void m_cmbGridSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_CtrlMutex.WaitOne();
            m_PushGraphCtrl.GridSize =
                (ushort)System.Convert.ToUInt32(m_cmbGridSize.Text);
            m_CtrlMutex.ReleaseMutex();
        }

        // ===================================================================       

        private void m_txtMinimumLabel_TextChanged(object sender, EventArgs e)
        {
            m_CtrlMutex.WaitOne();
            m_PushGraphCtrl.MinLabel = m_txtMinimumLabel.Text;
            m_CtrlMutex.ReleaseMutex();
        }

        // ===================================================================       

        private void m_txtMaximumLabel_TextChanged(object sender, EventArgs e)
        {
            m_CtrlMutex.WaitOne();
            m_PushGraphCtrl.MaxLabel = m_txtMaximumLabel.Text;
            m_CtrlMutex.ReleaseMutex();
        }

        // ===================================================================       

        private void m_btnImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Select Image";

            dlg.Filter = "Image Files|*.BMP;*.JPG;*.GIF";
            dlg.FilterIndex = 1;
            dlg.RestoreDirectory = true;
            dlg.Multiselect = false;

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                if (m_PushGraphCtrl.BackgroundImage != null)
                {
                    m_PushGraphCtrl.BackgroundImage.Dispose();
                    m_PushGraphCtrl.BackgroundImage = null;
                }

                m_CtrlMutex.WaitOne();
                m_PushGraphCtrl.BackgroundImage = Image.FromFile(dlg.FileName);
                m_PushGraphCtrl.BackgroundImageLayout = ImageLayout.Stretch;
                m_CtrlMutex.ReleaseMutex();
            }
        }

    }
}